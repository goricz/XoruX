#!/bin/sh
#
# LPAR2RRD install script
# usage: ./install.sh
#


LANG=C
export LANG

if [ ! "$1"x = "x" ]; then
  if [ "$1" = "wrap" ]; then
    # create a package, internall usage only
    ver=`grep "version=" dist/etc/lpar2rrd.cfg|sed 's/version=//g'`
    if [ "$ver"x = "x" ]; then
      echo "Something is wroing, cannot find the version"
      exit 1
    fi
    if [ -f lpar2rrd.tar.Z ]; then
      echo "removing lpar2rrd.tar.Z"
      rm lpar2rrd.tar.Z
    fi
    if [ -f lpar2rrd.tar ]; then
      echo "removing lpar2rrd.tar"
      rm lpar2rrd.tar
    fi
    tar cvf lpar2rrd.tar dist
    compress lpar2rrd.tar
    if [ -f lpar2rrd.tar.Z ]; then
      echo "removing dist"
      rm -r dist
    fi
    echo ""
    echo "$ver has been created"
    echo ""
    exit
  fi
fi

# test if "ed" command does not exist, it might happen especially on some Linux distros
ed << END 2>/dev/null 1>&2
q
END
if [ $? -gt 0 ]; then
  echo "ERROR: "ed" command does not seem to be installed or in $PATH"
  echo "Exiting ..."
  exit 1
fi


umask 0022 
ID=`id -un`
os_aix=` uname -a|grep AIX|wc -l`
if [ $os_aix -eq 0 ]; then
  ECHO_OPT="-e"
else
  ECHO_OPT=""
fi


echo "LPAR2RRD installation under user : \"$ID\""
echo " make sure it is realy the user which should own it"
echo ""
echo "Where LPAR2RRD will be installed [$HOME/lpar2rrd]:"
read HOMELPAR
echo ""

if [ "$HOMELPAR"x = "x" ]; then
    HOMELPAR="$HOME/lpar2rrd"
fi

if [ -f $HOMELPAR/bin/lpar2rrd.pl -o -f $HOMELPAR/lpar2rrd.pl ]; then
  echo "LPAR2RRD instance already exists there, use update.sh script for the update"
  exit 0
fi


if [ "$HOMELPAR"x = "x" ]; then
  HOMELPAR=$HOME/lpar2rrd
fi

if [ ! -d "$HOMELPAR" ]; then
  echo "Creating $HOMELPAR"
  echo ""
  mkdir "$HOMELPAR"
  if [ ! $? -eq 0 ]; then
    echo "Error during creation of $HOMELPAR, exiting ..."
    exit 0
  fi
fi

if [ -f lpar2rrd.tar.Z ]; then
  which uncompress >/dev/null 2>&1 
  if [ $? -eq 0 ]; then 
     uncompress -f lpar2rrd.tar.Z 
  else 
     which gunzip >/dev/null 2>&1 
     if [ $? -eq 0 ]; then 
       gunzip -f lpar2rrd.tar.Z 
     else 
       echo "Could not locate uncompress or gunzip commands. exiting" 
       exit 
     fi 
  fi 
fi

chown $ID $HOMELPAR
if [ ! $? -eq 0 ]; then
  echo "Problem with ownership of $HOMELPAR"
  echo "Fix it and run it again : chown  $ID $HOMELPAR"
  exit 0
fi

echo "Extracting distribution"
tar xf lpar2rrd.tar

echo "Copy distribution to the target location"
mv dist/* $HOMELPAR/

if [ -f version.txt ]; then
  version=`cat version.txt`
fi

#  put WEB files immediately after the upgrade to do not have to wait for the end of upgrade
echo "Copy GUI files : $HOMELPAR/www"
cp $HOMELPAR/html/*html $HOMELPAR/www
cp $HOMELPAR/html/*ico $HOMELPAR/www
cp $HOMELPAR/html/*png $HOMELPAR/www

cd $HOMELPAR/html
tar cf - jquery | (cd $HOMELPAR/www; tar xf - )
tar cf - css    | (cd $HOMELPAR/www; tar xf - )
cd - >/dev/null
if [ ! -f "$HOMELPAR/tmp/menu.txt" -a -f "$HOMELPAR/html/menu_default.txt" ]; then
  #place default menu.txt
  cp $HOMELPAR/html/menu_default.txt $HOMELPAR/tmp/menu.txt
fi


echo "Setting up directory permissions"
chown -R $ID $HOMELPAR 2>&1 |grep -v "lost+found"
chmod 755 $HOMELPAR
chmod 666 $HOMELPAR/logs/error.log
chmod 755 $HOMELPAR/data
chmod 755 $HOMELPAR/www
chmod 755 $HOMELPAR/bin
chmod 755 $HOMELPAR/etc
chmod 755 $HOMELPAR/scripts
chmod 755 $HOMELPAR/logs
if [ ! -d $HOMELPAR/tmp ]; then
  mkdir $HOMELPAR/tmp
fi
chmod 777 $HOMELPAR/tmp  # due to "Refresh" feature which need to save temp files there
chmod -R 755 $HOMELPAR/html  # must be due tue subdirs jquery, images ...
chmod -R 755 $HOMELPAR/lpar2rrd-cgi
chmod -R o+r $HOMELPAR/data
chmod -R o+x $HOMELPAR/data
chmod -R o+r $HOMELPAR/www
chmod -R o+x $HOMELPAR/www
chmod 755 $HOMELPAR/bin/*.pl
chmod 755 $HOMELPAR/bin/*.pm
chmod 755 $HOMELPAR/bin/*.sh
chmod 755 $HOMELPAR/*.sh
chmod 644 $HOMELPAR/etc/*
chmod 755 $HOMELPAR/scripts/*
chmod 644 $HOMELPAR/*.txt
if [ -h $HOMELPAR/error-cgi.log ]; then
  rm $HOMELPAR/error-cgi.log
fi
if [ -h $HOMELPAR/realt-error.log ]; then
  rm $HOMELPAR/realt-error.log
fi
if [ ! -h $HOMELPAR/logs/error-cgi.log ]; then
  ln -s /var/tmp/lpar2rrd-realt-error.log $HOMELPAR/logs/error-cgi.log
fi

if [ -f $HOMELPAR/etc/rperf_user.txt_template ]; then
  mv $HOMELPAR/etc/rperf_user.txt_template $HOMELPAR/etc/rperf_user.txt
fi

if [ ! -d "$HOMELPAR/etc/web_config" ]; then
  mkdir "$HOMELPAR/etc/web_config"
  chmod 777 "$HOMELPAR/etc/web_config"
fi


rrd=`whereis rrdtool|awk '{print $2}'|wc -w`
if [ $rrd -eq 0 ]; then
  echo ""
  echo "Warning: RRDTool has not been found in \$PATH, placing /opt/freeware/bin/rrdtool"
  echo "         assure it is ok, if not then edit $HOMELPAR/etc/lpar2rrd.cfg and change it"
  echo ""
  rrd="/opt/freeware/bin/rrdtool"
else
  rrd=`whereis rrdtool|awk '{print $2}'`
fi

if [ -f /opt/freeware/bin/perl ]; then
  per="/opt/freeware/bin/perl"
else 
  per=`whereis perl|awk '{print $2}'|wc -w`
  if [ $per -eq 0 ]; then
    echo ""
    echo "Warning: Perl has not been found in \$PATH, placing /usr/bin/perl"
    echo "         assure it is ok, if not then edit $HOMELPAR/etc/lpar2rrd.cfg and change it"
    echo ""
    per="/usr/bin/perl"
  else
    per=`whereis perl|awk '{print $2}'`
  fi
fi

# replace path for actual one in config files


HOMELPAR_slash=`echo $HOMELPAR|sed 's/\//\\\\\\//g'`
HOME_slash=`echo $HOME|sed 's/\//\\\\\\//g'`
rrd_slash=`echo $rrd|sed 's/\//\\\\\\//g'`
per_slash=`echo $per|sed 's/\//\\\\\\//g'`

# add actual paths
# perl/5.8.8 must be always first!
# /usr/lib64/perl5/vendor_perl/5.8.8 must be the first otherwize LibXML issues on AIX
PERL5LIB=/usr/lib64/perl5/vendor_perl/5.8.8:/opt/freeware/lib/perl/5.8.8:/opt/freeware/lib/perl/5.8.0:/usr/opt/perl5/lib/site_perl/5.8.2:/usr/lib/perl5/vendor_perl/5.8.5:/usr/share/perl5:/usr/lib/perl5:/usr/opt/perl5/lib/site_perl/5.8.8/aix-thread-multi:/opt/freeware/lib/perl5/vendor_perl/5.8.8/ppc-thread-multi:/usr/lib64/perl5/vendor_perl:/usr/lib/perl5/vendor_perl
PPATH="/opt/freeware/lib/perl
/usr/opt/perl5/lib/site_perl
/usr/lib64/perl5/vendor_perl"

perl_version=`$per -e 'print "$]\n"'|sed -e 's/0/\./g' -e 's/\.\.\.\./\./g' -e 's/\.\.\./\./g' -e 's/\.\./\./g' -e 's/ //g'`
PLIB=`for ppath in $PPATH
do
  echo $PERL5LIB|grep "$ppath/$perl_version"  >/dev/null
  if [ ! $? -eq 0 ]; then
    echo "$ppath/$perl_version"
   fi
done|xargs|sed 's/ /:/g'`

# VMware lib as the first one!
perl5lib_slash=`echo "$HOMELPAR/vmware-lib:$PLIB:$PERL5LIB"|sed -e 's/\//\\\\\\//g'`

 
echo "Configuring $HOMELPAR/etc/lpar2rrd.cfg" 
ed $HOMELPAR/etc/lpar2rrd.cfg << EOF 1>/dev/null
g/__LPAR2RRD_HOME__/s/__LPAR2RRD_HOME__/$HOMELPAR_slash/g
g/__USER_HOME__/s/__USER_HOME__/$HOME_slash/g
g/__LPAR2RRD_USER__/s/__LPAR2RRD_USER__/$ID/g
g/__RRDTOOL__/s/__RRDTOOL__/$rrd_slash/g
g/__PERL__/s/__PERL__/$per_slash/g
g/__PERL5LIB__/s/__PERL5LIB__/$perl5lib_slash/g
w
q
EOF
if [ ! $? -eq 0 ]; then
  echo ""
  echo "Error!"
  echo "Probably does not exist command: \"ed\" "
  echo "If it is the case then install ed, \"rm -r $HOMELPAR\" and run install once more"
  echo "Or customization of $HOMELPAR/etc/lpar2rrd.cfg failed"
  echo "Contact support in this case"
  exit 0
fi

# creating ssh keys if they do not exist
echo "" |ssh-keygen -t dsa -P "" 2>/dev/null 1>/dev/null
SSH_WEB_IDENT=$HOME/.ssh/realt_dsa
#if [ ! -f "$SSH_WEB_IDENT" ]; then 
#  # realt_dsa exist, then probably keay are already in place
#  echo "Do you want to create ssh-keys now (ssh-keygen -t dsa)?[n]"
#  read Y
#
#  if [ "$Y" = "y" -o "$Y" = "Y" ]; then
#    echo ""
#    ssh-keygen -t dsa
#    echo ""
#    echo ""
#  fi
#fi


WWW_USER=`ps -ef|egrep "apache|httpd"|grep -v grep|awk '{print $1}'|grep -v "root"|head -1`
if [ "$WWW_USER"x = x ]; then
  WWW_USER=nobody
fi

if [ ! -d $HOME/.ssh ]; then
    echo "Could not be found directory with ssh-keys ($HOME/.ssh)"
    echo " You wil need to do manually following:"
    echo " 1. create ssh-keys (ssh-keygen -t dsa)"
    echo " 2. copy keys to a new file and assign read rights for the web user : $WWW_USER"
    echo "   # cp $HOME/.ssh/id_dsa $HOME/.ssh/realt_dsa"
    echo "   under root account :"
    echo "   # chown $WWW_USER $HOME/.ssh/realt_dsa"
    echo "   # chmod 600 $HOME/.ssh/realt_dsa"
    echo ""
else
    if [ ! -f "$SSH_WEB_IDENT" ]; then 
      chmod 755 $HOME/.ssh
      if [ -f $HOME/.ssh/id_dsa ]; then
        cp -f $HOME/.ssh/id_dsa $SSH_WEB_IDENT
        chmod 600 $SSH_WEB_IDENT 
      else
        if [ -f $HOME/.ssh/id_rsa ]; then
          cp -f $HOME/.ssh/id_rsa $SSH_WEB_IDENT
          chmod 600 $SSH_WEB_IDENT 
        else
          echo "Could not be found ssh-keys in ($HOME/ssh)"
          echo " You wil need to do manually following:"
          echo " 1. create ssh-keys (ssh-keygen -t dsa)"
          echo " You wil need to do manually following:"
          echo " 2. copy keys to a new file and assign read rights for the web user : $WWW_USER"
          echo "   # cp $HOME/.ssh/id_dsa $HOME/.ssh/realt_dsa"
          echo "   under root account :"
          echo "   # chown $WWW_USER $SSH_WEB_IDENT
          echo "   # chmod 600 $SSH_WEB_IDENT
          echo ""
        fi
      fi
   fi
fi


# stop the agent daemon althought it is the installation!! who knows what user is doing ...
if [ -f "$HOMELPAR/tmp/lpar2rrd-daemon.pid" ]; then
  PID=`cat "$HOMELPAR/tmp/lpar2rrd-daemon.pid"|sed 's/ //g'`
  if [ ! "$PID"x = "x" ]; then
    echo "Stopping LPAR2RRD daemon"
    kill `cat "$HOMELPAR/tmp/lpar2rrd-daemon.pid"`
  fi
fi
run=`ps -ef|grep lpar2rrd-daemon.pl| egrep -v "grep |vi | vim "|wc -l`
if [ $run -gt 0 ]; then
  kill `ps -ef|grep lpar2rrd-daemon.pl| egrep -v "grep |vi | vim "|awk '{print $2}'` 2>/dev/null
fi


cd $HOMELPAR

# change #!bin/ksh in shell script to #!bin/bash on Linux platform
os_linux=` uname -a|grep Linux|wc -l`
if [ $os_linux -eq 1 ]; then
  # If Linux then change all "#!bin/sh --> #!bin/bash
  for sh in $HOMELPAR/bin/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/ksh/\/bash/
w
q
EOF
  done

  for sh in $HOMELPAR/scripts/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/ksh/\/bash/
w
q
EOF
  done

  for sh in $HOMELPAR/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/ksh/\/bash/
w
q
EOF
  done

  for sh in $HOMELPAR/lpar2rrd-cgi/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/ksh/\/bash/
w
q
EOF
  done

else
  # for AIX Solaris etc, all should be already in place just to be sure ...
  # change all "#!bin/bash --> #!bin/ksh
  for sh in $HOMELPAR/bin/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/bash/\/ksh/
w
q
EOF
  done

  for sh in $HOMELPAR/scripts/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/bash/\/ksh/
w
q
EOF
  done

  for sh in $HOMELPAR/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/bash/\/ksh/
w
q
EOF
  done

  for sh in $HOMELPAR/lpar2rrd-cgi/*.sh
  do
  ed $sh << EOF >/dev/null 2>&1
1s/\/bash/\/ksh/
w
q
EOF
  done
fi

# not necessary since 4.70 due to a new GUI
#echo ""
#echo "Custom groups config file creation"
#$HOMELPAR/scripts/update_cfg_custom-groups.sh update

# not longer used (since 4.75)
#echo ""
#echo "Favourites config file creation"
#$HOMELPAR/scripts/update_cfg_favourites.sh update

echo ""
echo "Alerting config file creation"
$HOMELPAR/scripts/update_cfg_alert.sh update

# Check web user has read&executable rights for CGI dir lpar2rrd-cgi
dir=`echo "$HOMELPAR/www"|sed 's/\\\//g'`
DIR=""
IFS_ORG=$IFS
IFS="/"
for i in $dir
do
  IFS=$IFS_ORG
  NEW_DIR=`echo $DIR$i/`
  #echo "01 $NEW_DIR -- $i -- $DIR ++ $www"
  NUM=`ls -dLl $NEW_DIR |awk '{print $1}'|sed -e 's/d//g' -e 's/-//g' -e 's/w//g' -e 's/\.//g'| wc -c`
  #echo "02 $NUM"
  if [ ! $NUM -eq 7 ]; then
    echo ""
    echo "WARNING, directory : $NEW_DIR has probably wrong rights"
    echo "         $www dir and its subdirs have to be executable&readable for WEB user"
    ls -lLd $NEW_DIR
    echo ""
  fi
  DIR=`echo "$NEW_DIR/"`
  #echo $DIR
  IFS="/"
done
IFS=$IFS_ORG


# ulimit check
# necessary for big aggregated graphs
#
# AIX:
# chuser  data=2097152 lpar2rrd (1GB)
# chuser  stack=524288 lpar2rrd (512MB)

ulimit_message=0
data=`ulimit -d`
if [ ! "$data" = "unlimited" -a ! "$data" = "hard" -a ! "$data" = "soft" ]; then
  if [ $data -lt 4194304 ]; then
    echo ""
    echo "Warning: increase data ulimit for $ID user, it is actually too low ($data)"
    echo "         AIX: chuser  data=2097152 $ID"
    echo " AIX: chuser  data=2097152 $ID"
    echo " Linux: # vi /etc/security/limits.conf"
    echo "        @$ID        soft    data            1048576"
    ulimit_message=1
  fi
fi
stack=`ulimit -s`
if [ ! "$stack" = "unlimited" -a ! "$stack" = "hard" -a ! "$data" = "soft" ]; then
  if [ $stack -lt 1048576 ]; then
    echo ""
    echo "Warning: increase stack ulimit for $ID user, it is actually too low ($stack)"
    echo " AIX: chuser  stack=524288 $ID"
    echo " Linux: # vi /etc/security/limits.conf"
    echo "        @$ID        soft    stack           524288"
    ulimit_message=1
  fi
fi
if [ $ulimit_message -eq 1 ]; then
  echo ""
  echo "Assure that the same limits has even web user (apache/nobody/http)"
  echo ""
fi


cd $HOMELPAR
if [ $os_aix -eq 0 ]; then
  free=`df .|grep -iv filesystem|xargs|awk '{print $4}'`
  freemb=`echo "$free/1048"|bc`
  if [ $freemb -lt 1024 ]; then
    echo ""
    echo "WARNING: free space in $HOMELPAR is too low : $freemb MB"
    echo "         note that 1 HMC needs about 1GB space depends on number of servers/lpars"
  fi
else
  free=`df .|grep -iv filesystem|xargs|awk '{print $3}'`
  freemb=`echo "$free/2048"|bc`
  if [ $freemb -lt 1024 ]; then
    echo ""
    echo "WARNING: free space in $HOMELPAR is too low : $freemb MB"
    echo "         note that 1 HMC needs about 1GB space depends on number of servers/lpars"
  fi
fi

# setting up the font dir (necessary for 1.3 on AIX)
FN_PATH="<?xml version=\"1.0\"?>
<!DOCTYPE fontconfig SYSTEM \"fonts.dtd\">
<fontconfig>
<dir>/opt/freeware/share/fonts/dejavu</dir>
</fontconfig>"

if [ ! -f "$HOME/.config/fontconfig/.fonts.conf" -o `grep -i deja "$HOME/.config/fontconfig/.fonts.conf" 2>/dev/null|wc -l` -eq 0 ]; then
  if [ ! -d "$HOME/.config" ]; then
    mkdir "$HOME/.config"
  fi
  if [ ! -d "$HOME/.config/fontconfig" ]; then
    mkdir "$HOME/.config/fontconfig"
  fi
  echo $FN_PATH > "$HOME/.config/fontconfig/.fonts.conf"
fi
chmod 644 "$HOME/.config/fontconfig/.fonts.conf"
# no, no, it issues this error:
# Fontconfig warning: "/opt/freeware/etc/fonts/conf.d/50-user.conf", line 9: reading configurations from ~/.fonts.conf is deprecated.
#if [ ! -f "$HOME/.fonts.conf" ]; then
#  echo $FN_PATH > "$HOME/.fonts.conf"
#  chmod 644 "$HOME/.fonts.conf"
#fi


# for web server user home
if [ ! -d "$HOMELPAR/tmp/home" ]; then
  mkdir "$HOMELPAR/tmp/home"
fi
#if [ ! -f "$HOMELPAR/tmp/home/.fonts.conf" ]; then
#  echo $FN_PATH > "$HOMELPAR/tmp/home/.fonts.conf"
#fi
if [ ! -d "$HOMELPAR/tmp/home/.config" ]; then
  mkdir "$HOMELPAR/tmp/home/.config"
fi
if [ ! -d "$HOMELPAR/tmp/home/.config/fontconfig" ]; then
  mkdir "$HOMELPAR/tmp/home/.config/fontconfig"
fi
if [ ! -f "$HOMELPAR/tmp/home/.config/fontconfig/fonts.conf" ]; then
  echo $FN_PATH > "$HOMELPAR/tmp/home/.config/fontconfig/fonts.conf"
fi
chmod 755 "$HOMELPAR/tmp/home"
chmod 755 "$HOMELPAR/tmp/home/.config"
chmod 755 "$HOMELPAR/tmp/home/.config/fontconfig"
chmod 644 "$HOMELPAR/tmp/home/.config/fontconfig/fonts.conf"

# Checking installed Perl modules
cd $HOMELPAR
. etc/lpar2rrd.cfg; $PERL bin/perl_modules_check.pl $PERL
echo ""
cd - >/dev/null

# RRDTool version checking for graph zooming
$rrd|grep graphv >/dev/null 2>&1
if [ $? -eq 1 ]; then
  # suggest RRDTool upgrade
  rrd_version=`$rrd -v|head -1|awk '{print $2}'`
  echo "Condider RRDtool upgrade to version 1.3.5+ (actual one is $rrd_version)"
  echo "This will allow graph zooming: http://www.lpar2rrd.com/zoom.html"
  echo ""
fi

if [ $os_linux -gt 0 ]; then
  # LinuxSE warning
  SELINUX=`ps -ef | grep -i selinux| grep -v grep|wc -l`

  if [ "$SELINUX" -gt 0  ]; then
    GETENFORCE=`getenforce 2>/dev/null`
    if [ "$GETENFORCE" = "Enforcing" ]; then
      echo ""
      echo "Warning!!!!!"
      echo "SELINUX status is Enforcing, it might cause a problem during Apache setup"
      echo "like this in Apache error_log: (13)Permission denied: access to /XXXX denied"
      echo ""
    fi
  fi
fi

#VMware
if [ ! -d "$HOMELPAR/.vmware" ]; then
  mkdir "$HOMELPAR/.vmware"
  chmod 755 "$HOMELPAR/.vmware"
fi
if [ ! -d "$HOMELPAR/.vmware/credstore" ]; then
  mkdir "$HOMELPAR/.vmware/credstore"
  chmod 777 "$HOMELPAR/.vmware/credstore" # must be 777 to allow writes of Apache user
fi

echo ""
echo "Installation has finished"
echo "Follow post-install instructions at:"
echo "  http://www.lpar2rrd.com/install.htm"

echo $version >> $HOMELPAR/etc/version.txt
echo "$HOMELPAR" > $HOME/.lpar2rrd_home 2>/dev/null

